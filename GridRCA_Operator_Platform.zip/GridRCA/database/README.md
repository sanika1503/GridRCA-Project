# Database

PostgreSQL is the primary structured database for the current GridRCA foundation.

Current starter tables:
- grid_assets
- telemetry
- incidents
- rca_results

Later:
- maintenance_records
- anomaly_events
- dataset_metadata
- RCA evaluation/ground-truth tables

Neo4j is reserved for graph relationships such as:

Sensor -> Equipment -> Bus -> Line -> Bus

Chroma/vector storage is reserved for RAG documents.
