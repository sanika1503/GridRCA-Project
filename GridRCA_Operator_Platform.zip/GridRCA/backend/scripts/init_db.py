from backend.app.db.postgres import Base, engine, SessionLocal
from backend.app.models import GridAsset, Telemetry, Incident, RCAResult
from backend.app.services.demo_service import demo_telemetry, demo_incidents, demo_rca


def seed():
    db = SessionLocal()
    try:
        if db.query(GridAsset).count() == 0:
            assets = [
                GridAsset(asset_id="G01", asset_type="GENERATOR", name="Generator G01"),
                GridAsset(asset_id="B01", asset_type="BUS", name="Bus B01"),
                GridAsset(asset_id="B12", asset_type="BUS", name="Bus B12", status="WARNING"),
                GridAsset(asset_id="T04", asset_type="TRANSFORMER", name="Transformer T04", status="CRITICAL"),
                GridAsset(asset_id="L12", asset_type="LINE", name="Line L12"),
                GridAsset(asset_id="G03", asset_type="GENERATOR", name="Generator G03", status="WARNING"),
            ]
            db.add_all(assets)

        if db.query(Telemetry).count() == 0:
            for row in demo_telemetry():
                db.add(Telemetry(**row))

        if db.query(Incident).count() == 0:
            for row in demo_incidents():
                db.add(Incident(**row))

        if db.query(RCAResult).count() == 0:
            rca = demo_rca("INC-2026-001")
            db.add(RCAResult(
                incident_id=rca["incident_id"],
                probable_cause=rca["probable_cause"],
                confidence=rca["confidence"],
                evidence="; ".join(rca["evidence"]),
                recommendation=rca["recommendation"],
            ))

        db.commit()
        print("GridRCA database initialized and seeded.")
    finally:
        db.close()


if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    seed()
