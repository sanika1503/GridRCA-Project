from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.app.core.config import get_settings
from backend.app.api import health, telemetry, incidents, rca, topology

settings = get_settings()

app = FastAPI(
    title="GridRCA API",
    description="Grid operator monitoring and root-cause investigation API.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

prefix = settings.api_prefix
app.include_router(health.router, prefix=prefix)
app.include_router(telemetry.router, prefix=prefix)
app.include_router(incidents.router, prefix=prefix)
app.include_router(rca.router, prefix=prefix)
app.include_router(topology.router, prefix=prefix)


@app.get("/")
def root():
    return {
        "name": "GridRCA",
        "status": "online",
        "message": "Grid operator intelligence API is running.",
    }
