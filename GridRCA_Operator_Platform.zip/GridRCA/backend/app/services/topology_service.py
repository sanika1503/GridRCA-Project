from backend.app.services.demo_service import demo_topology


def get_topology():
    # Later this function will query Neo4j.
    return demo_topology()
