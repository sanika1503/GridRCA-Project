from sqlalchemy import select
from sqlalchemy.orm import Session
from backend.app.models import Telemetry
from backend.app.services.demo_service import demo_telemetry


def latest_telemetry(db: Session, limit: int = 20):
    try:
        rows = db.execute(
            select(Telemetry).order_by(Telemetry.timestamp.desc()).limit(limit)
        ).scalars().all()
        if rows:
            return rows
    except Exception:
        # The API remains usable while PostgreSQL is being configured.
        db.rollback()
    return demo_telemetry()[:limit]
