from backend.app.services.demo_service import demo_rca


def investigate(incident_id: str):
    # Research RCA pipeline will replace this service later.
    # Keeping the interface stable means the frontend does not need rewriting.
    return demo_rca(incident_id)
