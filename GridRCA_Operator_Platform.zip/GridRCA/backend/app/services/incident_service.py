from sqlalchemy import select
from sqlalchemy.orm import Session
from backend.app.models import Incident
from backend.app.services.demo_service import demo_incidents


def list_incidents(db: Session, limit: int = 20):
    try:
        rows = db.execute(
            select(Incident).order_by(Incident.detected_at.desc()).limit(limit)
        ).scalars().all()
        if rows:
            return rows
    except Exception:
        db.rollback()
    return demo_incidents()[:limit]


def get_incident(db: Session, incident_id: str):
    try:
        row = db.execute(
            select(Incident).where(Incident.incident_id == incident_id)
        ).scalar_one_or_none()
        if row:
            return row
    except Exception:
        db.rollback()

    for item in demo_incidents():
        if item["incident_id"] == incident_id:
            return item
    return None
