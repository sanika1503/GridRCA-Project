from datetime import datetime, timedelta, timezone


def demo_telemetry():
    now = datetime.now(timezone.utc)
    rows = []
    assets = [
        ("B01", "Voltage", 1.02, "pu", "NORMAL"),
        ("B02", "Voltage", 0.99, "pu", "NORMAL"),
        ("L12", "Active Power", 86.4, "MW", "NORMAL"),
        ("T04", "Temperature", 101.8, "°C", "ANOMALY"),
        ("G03", "Frequency", 49.82, "Hz", "WARNING"),
    ]
    for i, (asset, metric, value, unit, status) in enumerate(assets):
        rows.append({
            "timestamp": now - timedelta(seconds=i * 2),
            "asset_id": asset,
            "metric": metric,
            "value": value,
            "unit": unit,
            "status": status,
        })
    return rows


def demo_incidents():
    now = datetime.now(timezone.utc)
    return [
        {
            "incident_id": "INC-2026-001",
            "title": "Transformer T04 overheating",
            "severity": "CRITICAL",
            "asset_id": "T04",
            "status": "INVESTIGATING",
            "description": "Temperature exceeded the configured operating threshold.",
            "detected_at": now,
        },
        {
            "incident_id": "INC-2026-002",
            "title": "Frequency deviation at G03",
            "severity": "HIGH",
            "asset_id": "G03",
            "status": "OPEN",
            "description": "Frequency moved outside the normal operating band.",
            "detected_at": now - timedelta(minutes=8),
        },
        {
            "incident_id": "INC-2026-003",
            "title": "Line L12 loading increase",
            "severity": "MEDIUM",
            "asset_id": "L12",
            "status": "MONITORING",
            "description": "Power flow is elevated compared with the recent baseline.",
            "detected_at": now - timedelta(minutes=19),
        },
    ]


def demo_rca(incident_id: str):
    return {
        "incident_id": incident_id,
        "probable_cause": "Cooling-system degradation",
        "confidence": 0.87,
        "evidence": [
            "Transformer T04 temperature is above its configured threshold.",
            "Temperature trend shows a sustained upward movement.",
            "The affected transformer is connected to the B12 topology area.",
            "A maintenance-history signal can be used as supporting evidence once loaded.",
        ],
        "recommendation": "Inspect cooling equipment and verify fan/pump operation before returning the asset to normal operating conditions.",
    }


def demo_topology():
    nodes = [
        {"id": "G01", "label": "Generator G01", "type": "GENERATOR", "status": "NORMAL"},
        {"id": "B01", "label": "Bus B01", "type": "BUS", "status": "NORMAL"},
        {"id": "L12", "label": "Line L12", "type": "LINE", "status": "NORMAL"},
        {"id": "B12", "label": "Bus B12", "type": "BUS", "status": "WARNING"},
        {"id": "T04", "label": "Transformer T04", "type": "TRANSFORMER", "status": "CRITICAL"},
        {"id": "B13", "label": "Bus B13", "type": "BUS", "status": "NORMAL"},
        {"id": "L13", "label": "Line L13", "type": "LINE", "status": "NORMAL"},
    ]
    edges = [
        {"source": "G01", "target": "B01", "relationship": "CONNECTED_TO"},
        {"source": "B01", "target": "L12", "relationship": "FEEDS"},
        {"source": "L12", "target": "B12", "relationship": "CONNECTS"},
        {"source": "B12", "target": "T04", "relationship": "SUPPLIES"},
        {"source": "T04", "target": "B13", "relationship": "FEEDS"},
        {"source": "B13", "target": "L13", "relationship": "FEEDS"},
    ]
    return {"nodes": nodes, "edges": edges}
