from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from backend.app.db.postgres import get_db
from backend.app.services.telemetry_service import latest_telemetry
from backend.app.schemas.common import TelemetryOut

router = APIRouter(prefix="/telemetry", tags=["Telemetry"])


@router.get("/latest", response_model=list[TelemetryOut])
def get_latest(
    limit: int = Query(default=20, ge=1, le=500),
    db: Session = Depends(get_db),
):
    return latest_telemetry(db, limit)
