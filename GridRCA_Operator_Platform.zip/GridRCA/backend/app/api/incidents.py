from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from backend.app.db.postgres import get_db
from backend.app.services.incident_service import list_incidents, get_incident
from backend.app.schemas.common import IncidentOut

router = APIRouter(prefix="/incidents", tags=["Incidents"])


@router.get("", response_model=list[IncidentOut])
def incidents(
    limit: int = Query(default=20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    return list_incidents(db, limit)


@router.get("/{incident_id}", response_model=IncidentOut)
def incident(incident_id: str, db: Session = Depends(get_db)):
    item = get_incident(db, incident_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Incident not found")
    return item
