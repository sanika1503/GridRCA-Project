from fastapi import APIRouter
from backend.app.services.rca_service import investigate
from backend.app.schemas.common import RCAOut

router = APIRouter(prefix="/rca", tags=["RCA"])


@router.get("/investigate/{incident_id}", response_model=RCAOut)
def investigate_incident(incident_id: str):
    return investigate(incident_id)
