from fastapi import APIRouter
from backend.app.services.topology_service import get_topology

router = APIRouter(prefix="/topology", tags=["Topology"])


@router.get("")
def topology():
    return get_topology()
