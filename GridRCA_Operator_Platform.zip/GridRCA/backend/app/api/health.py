from fastapi import APIRouter
from sqlalchemy import text
from backend.app.core.config import get_settings
from backend.app.db.neo4j import neo4j_service
from backend.app.db.postgres import SessionLocal

router = APIRouter(tags=["Health"])
settings = get_settings()


@router.get("/health")
def health():
    database = "disconnected"
    db = SessionLocal()
    try:
        db.execute(text("SELECT 1"))
        database = "connected"
    except Exception:
        database = "unavailable"
    finally:
        db.close()

    return {
        "status": "ok",
        "service": settings.app_name,
        "database": database,
        "neo4j": neo4j_service.health(),
    }
