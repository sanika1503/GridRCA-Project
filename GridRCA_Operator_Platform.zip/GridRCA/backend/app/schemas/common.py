from datetime import datetime
from pydantic import BaseModel, ConfigDict


class HealthResponse(BaseModel):
    status: str
    service: str
    database: str
    neo4j: dict


class TelemetryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    timestamp: datetime
    asset_id: str
    metric: str
    value: float
    unit: str | None = None
    status: str


class IncidentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    incident_id: str
    title: str
    severity: str
    asset_id: str | None
    status: str
    description: str | None
    detected_at: datetime


class RCAOut(BaseModel):
    incident_id: str
    probable_cause: str
    confidence: float
    evidence: list[str]
    recommendation: str


class TopologyNode(BaseModel):
    id: str
    label: str
    type: str
    status: str


class TopologyEdge(BaseModel):
    source: str
    target: str
    relationship: str
