from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, Text
from backend.app.db.postgres import Base


class GridAsset(Base):
    __tablename__ = "grid_assets"

    id = Column(Integer, primary_key=True)
    asset_id = Column(String(64), unique=True, nullable=False, index=True)
    asset_type = Column(String(64), nullable=False)
    name = Column(String(128), nullable=False)
    status = Column(String(32), default="NORMAL")
    location = Column(String(128), nullable=True)


class Telemetry(Base):
    __tablename__ = "telemetry"

    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    asset_id = Column(String(64), index=True, nullable=False)
    metric = Column(String(64), nullable=False)
    value = Column(Float, nullable=False)
    unit = Column(String(32), nullable=True)
    status = Column(String(32), default="NORMAL")


class Incident(Base):
    __tablename__ = "incidents"

    id = Column(Integer, primary_key=True)
    incident_id = Column(String(64), unique=True, nullable=False, index=True)
    title = Column(String(256), nullable=False)
    severity = Column(String(32), default="MEDIUM")
    asset_id = Column(String(64), nullable=True)
    status = Column(String(32), default="OPEN")
    description = Column(Text, nullable=True)
    detected_at = Column(DateTime, default=datetime.utcnow)


class RCAResult(Base):
    __tablename__ = "rca_results"

    id = Column(Integer, primary_key=True)
    incident_id = Column(String(64), index=True, nullable=False)
    probable_cause = Column(String(256), nullable=False)
    confidence = Column(Float, nullable=False)
    evidence = Column(Text, nullable=True)
    recommendation = Column(Text, nullable=True)
