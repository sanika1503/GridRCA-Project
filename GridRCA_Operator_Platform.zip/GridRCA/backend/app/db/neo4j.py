from neo4j import GraphDatabase
from backend.app.core.config import get_settings

settings = get_settings()


class Neo4jService:
    def __init__(self):
        self.driver = None
        if settings.neo4j_password:
            self.driver = GraphDatabase.driver(
                settings.neo4j_uri,
                auth=(settings.neo4j_user, settings.neo4j_password),
            )

    def health(self) -> dict:
        if self.driver is None:
            return {
                "configured": False,
                "connected": False,
                "message": "Neo4j is not configured yet.",
            }

        try:
            self.driver.verify_connectivity()
            return {
                "configured": True,
                "connected": True,
                "message": "Neo4j connection is healthy.",
            }
        except Exception as exc:
            return {
                "configured": True,
                "connected": False,
                "message": str(exc),
            }

    def close(self):
        if self.driver:
            self.driver.close()


neo4j_service = Neo4jService()
