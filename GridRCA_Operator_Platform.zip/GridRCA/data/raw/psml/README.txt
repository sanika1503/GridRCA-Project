PSML DATASET LOCATION

1. Keep your original PSML ZIP in:
   data/raw/psml/archive/

2. Extract the ZIP into:
   data/raw/psml/extracted/

3. Do not rename/delete files until we inspect the dataset.

4. The next project step will be:
   PSML inspection -> identify file types -> identify columns/records -> write PSML ingestion script -> load selected data into PostgreSQL.

The current application does not yet assume a specific PSML schema because we should inspect the exact dataset you downloaded before writing an importer.
