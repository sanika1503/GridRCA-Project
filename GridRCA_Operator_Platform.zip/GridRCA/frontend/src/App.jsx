import { useEffect, useState } from "react";
import { Routes, Route } from "react-router-dom";
import AppShell from "./components/AppShell";
import Operations from "./pages/Operations";
import Telemetry from "./pages/Telemetry";
import Incidents from "./pages/Incidents";
import Topology from "./pages/Topology";
import RCA from "./pages/RCA";
import Evidence from "./pages/Evidence";
import Settings from "./pages/Settings";
import { api } from "./services/api";

export default function App() {
  const [apiStatus, setApiStatus] = useState(false);

  useEffect(() => {
    api.health().then(() => setApiStatus(true)).catch(() => setApiStatus(false));
  }, []);

  return (
    <AppShell apiStatus={apiStatus}>
      <Routes>
        <Route path="/" element={<Operations />} />
        <Route path="/telemetry" element={<Telemetry />} />
        <Route path="/incidents" element={<Incidents />} />
        <Route path="/topology" element={<Topology />} />
        <Route path="/rca" element={<RCA />} />
        <Route path="/evidence" element={<Evidence />} />
        <Route path="/settings" element={<Settings />} />
      </Routes>
    </AppShell>
  );
}
