function nodePosition(id) {
  const positions = {
    G01: [70, 170],
    B01: [230, 170],
    L12: [390, 170],
    B12: [550, 170],
    T04: [710, 170],
    B13: [850, 170],
    L13: [990, 170],
  };
  return positions[id] || [100, 100];
}

export default function TopologyGraph({ graph }) {
  if (!graph) return null;

  return (
    <div className="topology-canvas">
      <svg viewBox="0 0 1080 340" role="img" aria-label="Grid topology">
        {graph.edges.map((edge, index) => {
          const [x1, y1] = nodePosition(edge.source);
          const [x2, y2] = nodePosition(edge.target);
          return (
            <g key={`${edge.source}-${edge.target}-${index}`}>
              <line x1={x1} y1={y1} x2={x2} y2={y2} className="topology-edge" />
              <text x={(x1 + x2) / 2} y={y1 - 13} className="edge-label">
                {edge.relationship}
              </text>
            </g>
          );
        })}
        {graph.nodes.map((node) => {
          const [x, y] = nodePosition(node.id);
          return (
            <g key={node.id}>
              <circle
                cx={x}
                cy={y}
                r="25"
                className={`topology-node node-${node.status.toLowerCase()}`}
              />
              <text x={x} y={y + 4} textAnchor="middle" className="node-id">
                {node.id}
              </text>
              <text x={x} y={y + 52} textAnchor="middle" className="node-label">
                {node.type}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
