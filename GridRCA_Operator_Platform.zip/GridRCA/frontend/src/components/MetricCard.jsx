export default function MetricCard({ label, value, sub, icon: Icon, tone = "" }) {
  return (
    <div className={`metric-card ${tone}`}>
      <div className="metric-icon">{Icon && <Icon size={18} />}</div>
      <div>
        <div className="metric-label">{label}</div>
        <div className="metric-value">{value}</div>
        {sub && <div className="metric-sub">{sub}</div>}
      </div>
    </div>
  );
}
