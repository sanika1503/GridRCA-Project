import { NavLink } from "react-router-dom";
import {
  Activity, AlertTriangle, Network, Search, FileText, Settings,
  LayoutDashboard, Radio
} from "lucide-react";

const links = [
  { to: "/", label: "Operations", icon: LayoutDashboard },
  { to: "/telemetry", label: "Live Telemetry", icon: Radio },
  { to: "/incidents", label: "Incidents", icon: AlertTriangle },
  { to: "/topology", label: "Topology", icon: Network },
  { to: "/rca", label: "RCA Investigation", icon: Search },
  { to: "/evidence", label: "Evidence", icon: FileText },
  { to: "/settings", label: "System", icon: Settings },
];

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-mark"><Activity size={21} /></div>
        <div>
          <div className="brand-name">GridRCA</div>
          <div className="brand-sub">Grid Intelligence Center</div>
        </div>
      </div>

      <div className="nav-section-title">OPERATIONS</div>
      <nav>
        {links.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/"}
            className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
          >
            <Icon size={17} />
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="sidebar-footer">
        <div className="online-dot" />
        <div>
          <strong>System Online</strong>
          <span>API connection active</span>
        </div>
      </div>
    </aside>
  );
}
