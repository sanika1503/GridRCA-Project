import { Bell, CircleHelp, UserRound } from "lucide-react";
import Sidebar from "./Sidebar";

export default function AppShell({ children, apiStatus }) {
  return (
    <div className="app-shell">
      <Sidebar />
      <div className="main-area">
        <header className="topbar">
          <div className="topbar-context">
            <span className="topbar-kicker">CITY GRID OPERATIONS</span>
            <span className={`connection-pill ${apiStatus ? "connected" : "offline"}`}>
              <span className="connection-dot" />
              {apiStatus ? "API CONNECTED" : "API OFFLINE"}
            </span>
          </div>
          <div className="topbar-actions">
            <button className="icon-button" title="Notifications"><Bell size={18} /></button>
            <button className="icon-button" title="Help"><CircleHelp size={18} /></button>
            <div className="operator">
              <div className="avatar"><UserRound size={17} /></div>
              <div><strong>Grid Operator</strong><span>Control Room</span></div>
            </div>
          </div>
        </header>
        <main className="content">{children}</main>
      </div>
    </div>
  );
}
