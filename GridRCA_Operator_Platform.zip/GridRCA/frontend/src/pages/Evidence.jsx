import PageHeader from "../components/PageHeader";

export default function Evidence() {
  const sources = [
    ["PSML telemetry", "data/raw/psml", "Dataset / telemetry source"],
    ["Historical incidents", "data/incidents", "Future incident corpus"],
    ["Maintenance records", "data/maintenance", "Future asset-history source"],
    ["Engineering documents", "data/knowledge/documents", "Future RAG corpus"],
  ];

  return (
    <>
      <PageHeader
        eyebrow="KNOWLEDGE & PROVENANCE"
        title="Evidence Repository"
        description="The evidence layer is designed to keep RCA explanations grounded in traceable project data."
      />
      <div className="source-grid">
        {sources.map(([name, path, desc]) => (
          <div className="source-card" key={name}>
            <div className="source-icon">▣</div>
            <div><strong>{name}</strong><span>{desc}</span><code>{path}</code></div>
          </div>
        ))}
      </div>
      <section className="panel roadmap-panel">
        <div className="panel-title">Evidence pipeline — next phase</div>
        <div className="panel-sub">This UI is already prepared for the research components that will be connected later.</div>
        <div className="pipeline">
          {["PSML / telemetry", "Anomaly event", "Topology + lineage", "Hybrid retrieval", "RCA evidence", "Operator decision"].map((x, i) => (
            <div className="pipeline-step" key={x}><b>0{i+1}</b><span>{x}</span></div>
          ))}
        </div>
      </section>
    </>
  );
}
