import { useEffect, useState } from "react";
import { Activity, AlertTriangle, Network, Search, ShieldCheck, Zap } from "lucide-react";
import PageHeader from "../components/PageHeader";
import MetricCard from "../components/MetricCard";
import StatusBadge from "../components/StatusBadge";
import TopologyGraph from "../components/TopologyGraph";
import { api } from "../services/api";

export default function Operations() {
  const [telemetry, setTelemetry] = useState([]);
  const [incidents, setIncidents] = useState([]);
  const [topology, setTopology] = useState(null);

  useEffect(() => {
    Promise.all([api.telemetry(), api.incidents(), api.topology()])
      .then(([t, i, g]) => {
        setTelemetry(t);
        setIncidents(i);
        setTopology(g);
      })
      .catch(() => {});
  }, []);

  const critical = incidents.filter(x => x.severity === "CRITICAL").length;
  const anomalies = telemetry.filter(x => x.status === "ANOMALY").length;

  return (
    <>
      <PageHeader
        eyebrow="LIVE OPERATIONS"
        title="Grid Operations Overview"
        description="Monitor system condition, active events and investigation readiness from one control-room view."
        action={<div className="live-chip"><span /> LIVE MONITORING</div>}
      />

      <div className="metric-grid">
        <MetricCard label="Grid Assets" value={topology?.nodes?.length ?? "—"} sub="Topology entities loaded" icon={Network} />
        <MetricCard label="Active Incidents" value={incidents.length || "—"} sub={`${critical} critical`} icon={AlertTriangle} tone={critical ? "danger" : ""} />
        <MetricCard label="Telemetry Signals" value={telemetry.length || "—"} sub={`${anomalies} anomalies detected`} icon={Activity} tone={anomalies ? "warning" : ""} />
        <MetricCard label="RCA Readiness" value="READY" sub="Investigation service available" icon={ShieldCheck} />
      </div>

      <div className="two-column">
        <section className="panel">
          <div className="panel-header">
            <div><div className="panel-title">Grid Topology</div><div className="panel-sub">Affected assets highlighted for operator context</div></div>
            <a href="/topology" className="text-link">Open topology →</a>
          </div>
          <TopologyGraph graph={topology} />
        </section>

        <section className="panel">
          <div className="panel-header">
            <div><div className="panel-title">Priority Incidents</div><div className="panel-sub">Most recent operational events</div></div>
            <a href="/incidents" className="text-link">View all →</a>
          </div>
          <div className="incident-list">
            {incidents.slice(0, 4).map(item => (
              <div className="incident-row" key={item.incident_id}>
                <div className="incident-severity"><span /></div>
                <div className="incident-main">
                  <strong>{item.title}</strong>
                  <span>{item.asset_id} · {item.incident_id}</span>
                </div>
                <StatusBadge value={item.severity} />
              </div>
            ))}
          </div>
        </section>
      </div>

      <section className="panel">
        <div className="panel-header">
          <div><div className="panel-title">Latest Telemetry</div><div className="panel-sub">Current values returned by the API</div></div>
          <a href="/telemetry" className="text-link">Open telemetry →</a>
        </div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Timestamp</th><th>Asset</th><th>Metric</th><th>Value</th><th>Unit</th><th>Status</th></tr></thead>
            <tbody>
              {telemetry.slice(0, 8).map((row, i) => (
                <tr key={`${row.asset_id}-${row.metric}-${i}`}>
                  <td>{new Date(row.timestamp).toLocaleTimeString()}</td>
                  <td><strong>{row.asset_id}</strong></td>
                  <td>{row.metric}</td>
                  <td className="value-cell">{Number(row.value).toFixed(2)}</td>
                  <td>{row.unit}</td>
                  <td><StatusBadge value={row.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
