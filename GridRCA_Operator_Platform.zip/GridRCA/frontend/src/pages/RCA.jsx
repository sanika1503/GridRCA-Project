import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { CheckCircle2, FileSearch, ShieldAlert } from "lucide-react";
import PageHeader from "../components/PageHeader";
import { api } from "../services/api";

export default function RCA() {
  const [params] = useSearchParams();
  const [incidentId, setIncidentId] = useState(params.get("incident") || "INC-2026-001");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const investigate = () => {
    setLoading(true);
    api.rca(incidentId).then(setResult).finally(() => setLoading(false));
  };

  useEffect(() => { investigate(); }, []);

  return (
    <>
      <PageHeader
        eyebrow="INVESTIGATION WORKBENCH"
        title="Root-Cause Investigation"
        description="Investigate a detected event using the RCA service. The current implementation is a stable integration shell for the future anomaly + topology + RAG pipeline."
      />

      <section className="investigation-bar panel">
        <div><label>Incident ID</label><input value={incidentId} onChange={e => setIncidentId(e.target.value)} /></div>
        <button className="button primary" onClick={investigate} disabled={loading}><FileSearch size={16} /> {loading ? "Investigating..." : "Run Investigation"}</button>
      </section>

      {result && (
        <div className="rca-grid">
          <section className="panel rca-main">
            <div className="eyebrow">PROBABLE ROOT CAUSE</div>
            <div className="cause-title">{result.probable_cause}</div>
            <div className="confidence-row">
              <div><span>Investigation confidence</span><strong>{Math.round(result.confidence * 100)}%</strong></div>
              <div className="confidence-track"><div style={{ width: `${result.confidence * 100}%` }} /></div>
            </div>
            <div className="recommendation"><ShieldAlert size={19} /><div><strong>Recommended operator action</strong><p>{result.recommendation}</p></div></div>
          </section>

          <section className="panel">
            <div className="panel-title">Supporting Evidence</div>
            <div className="panel-sub">Evidence items returned by the investigation layer</div>
            <div className="evidence-list">
              {result.evidence.map((item, i) => <div className="evidence-item" key={i}><CheckCircle2 size={17} /><span>{item}</span></div>)}
            </div>
          </section>
        </div>
      )}
    </>
  );
}
