import { useEffect, useState } from "react";
import PageHeader from "../components/PageHeader";
import TopologyGraph from "../components/TopologyGraph";
import StatusBadge from "../components/StatusBadge";
import { api } from "../services/api";

export default function Topology() {
  const [graph, setGraph] = useState(null);

  useEffect(() => { api.topology().then(setGraph).catch(() => {}); }, []);

  return (
    <>
      <PageHeader
        eyebrow="GRID RELATIONSHIPS"
        title="Topology & Data Lineage"
        description="View how assets connect. This context will later drive lineage-aware retrieval for RCA."
      />
      <section className="panel">
        <div className="panel-header">
          <div><div className="panel-title">Network View</div><div className="panel-sub">Current API graph representation</div></div>
          <div className="legend"><span className="legend-item"><i className="dot normal" /> Normal</span><span className="legend-item"><i className="dot warning" /> Warning</span><span className="legend-item"><i className="dot critical" /> Critical</span></div>
        </div>
        <TopologyGraph graph={graph} />
      </section>
      <section className="panel">
        <div className="panel-header"><div><div className="panel-title">Grid Entities</div><div className="panel-sub">Nodes returned by the topology service</div></div></div>
        <div className="node-grid">
          {(graph?.nodes || []).map(node => (
            <div className="node-card" key={node.id}>
              <div><strong>{node.id}</strong><StatusBadge value={node.status} /></div>
              <span>{node.label}</span>
              <small>{node.type}</small>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
