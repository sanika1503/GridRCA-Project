import { useEffect, useState } from "react";
import { RefreshCw, Radio } from "lucide-react";
import PageHeader from "../components/PageHeader";
import StatusBadge from "../components/StatusBadge";
import { api } from "../services/api";

export default function Telemetry() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);

  const load = () => {
    setLoading(true);
    api.telemetry().then(setRows).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  return (
    <>
      <PageHeader
        eyebrow="REAL-TIME DATA"
        title="Live Telemetry"
        description="Inspect the latest measurements arriving from the grid data layer."
        action={<button className="button secondary" onClick={load}><RefreshCw size={16} className={loading ? "spin" : ""} /> Refresh</button>}
      />
      <section className="panel">
        <div className="panel-header">
          <div><div className="panel-title">Signal Feed</div><div className="panel-sub">Latest 20 measurements</div></div>
          <div className="feed-status"><Radio size={15} /> Feed active</div>
        </div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Time</th><th>Asset</th><th>Metric</th><th>Value</th><th>Unit</th><th>Condition</th></tr></thead>
            <tbody>
              {rows.map((row, i) => (
                <tr key={i}>
                  <td>{new Date(row.timestamp).toLocaleString()}</td>
                  <td><strong>{row.asset_id}</strong></td>
                  <td>{row.metric}</td>
                  <td className="value-cell">{Number(row.value).toFixed(3)}</td>
                  <td>{row.unit || "—"}</td>
                  <td><StatusBadge value={row.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
