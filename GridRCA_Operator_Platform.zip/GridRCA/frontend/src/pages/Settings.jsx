import { useEffect, useState } from "react";
import PageHeader from "../components/PageHeader";
import StatusBadge from "../components/StatusBadge";
import { api } from "../services/api";

export default function Settings() {
  const [health, setHealth] = useState(null);

  useEffect(() => { api.health().then(setHealth).catch(() => setHealth(null)); }, []);

  return (
    <>
      <PageHeader eyebrow="SYSTEM STATUS" title="System Configuration" description="Connection status and deployment components for the GridRCA development environment." />
      <div className="system-grid">
        <div className="system-card"><span>Frontend</span><strong>React + Vite</strong><StatusBadge value="READY" /></div>
        <div className="system-card"><span>Backend</span><strong>FastAPI</strong><StatusBadge value={health ? "CONNECTED" : "OFFLINE"} /></div>
        <div className="system-card"><span>PostgreSQL</span><strong>Structured data</strong><StatusBadge value={health?.database === "connected" ? "CONNECTED" : "CHECK"} /></div>
        <div className="system-card"><span>Neo4j</span><strong>Topology / lineage</strong><StatusBadge value={health?.neo4j?.connected ? "CONNECTED" : "PREPARED"} /></div>
        <div className="system-card"><span>RAG / Chroma</span><strong>Knowledge retrieval</strong><StatusBadge value="NEXT PHASE" /></div>
        <div className="system-card"><span>Dataset</span><strong>PSML</strong><StatusBadge value="READY FOR INGESTION" /></div>
      </div>
    </>
  );
}
