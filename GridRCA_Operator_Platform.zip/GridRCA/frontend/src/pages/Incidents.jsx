import { useEffect, useState } from "react";
import { Search } from "lucide-react";
import PageHeader from "../components/PageHeader";
import StatusBadge from "../components/StatusBadge";
import { api } from "../services/api";

export default function Incidents() {
  const [rows, setRows] = useState([]);
  const [selected, setSelected] = useState(null);

  useEffect(() => { api.incidents().then(setRows).catch(() => {}); }, []);

  return (
    <>
      <PageHeader
        eyebrow="EVENT MANAGEMENT"
        title="Incident Command"
        description="Review detected events and move a selected incident into root-cause investigation."
      />
      <div className="two-column incident-layout">
        <section className="panel">
          <div className="panel-header"><div><div className="panel-title">Active Events</div><div className="panel-sub">{rows.length} events returned</div></div></div>
          <div className="incident-table">
            {rows.map(item => (
              <button key={item.incident_id} className={`incident-card ${selected?.incident_id === item.incident_id ? "selected" : ""}`} onClick={() => setSelected(item)}>
                <div className="card-top"><span>{item.incident_id}</span><StatusBadge value={item.severity} /></div>
                <strong>{item.title}</strong>
                <span>{item.asset_id} · {item.status}</span>
              </button>
            ))}
          </div>
        </section>

        <section className="panel detail-panel">
          {selected ? (
            <>
              <div className="eyebrow">SELECTED INCIDENT</div>
              <h2>{selected.title}</h2>
              <div className="detail-meta"><StatusBadge value={selected.severity} /><span>{selected.incident_id}</span><span>{selected.asset_id}</span></div>
              <div className="detail-block"><label>Operational description</label><p>{selected.description}</p></div>
              <div className="detail-block"><label>Detected</label><p>{new Date(selected.detected_at).toLocaleString()}</p></div>
              <a className="button primary" href={`/rca?incident=${encodeURIComponent(selected.incident_id)}`}><Search size={16} /> Investigate with RCA</a>
            </>
          ) : (
            <div className="empty-state"><Search size={30} /><h3>Select an incident</h3><p>Choose an event to inspect its details and launch RCA.</p></div>
          )}
        </section>
      </div>
    </>
  );
}
