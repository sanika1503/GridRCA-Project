const API_BASE = import.meta.env.VITE_API_BASE || "http://127.0.0.1:8000/api/v1";

async function request(path) {
  const response = await fetch(`${API_BASE}${path}`);
  if (!response.ok) {
    throw new Error(`API request failed: ${response.status}`);
  }
  return response.json();
}

export const api = {
  health: () => request("/health"),
  telemetry: () => request("/telemetry/latest?limit=20"),
  incidents: () => request("/incidents?limit=20"),
  incident: (id) => request(`/incidents/${encodeURIComponent(id)}`),
  rca: (id) => request(`/rca/investigate/${encodeURIComponent(id)}`),
  topology: () => request("/topology"),
};
