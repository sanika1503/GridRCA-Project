# GridRCA Architecture

## Current working path

React operator UI
    ↓ HTTP/JSON
FastAPI
    ↓
Service layer
    ↓
PostgreSQL

Topology service currently returns a demo graph. Later:
FastAPI → Neo4j

RCA service currently returns a controlled demo result. Later:
Anomaly → lineage context → hybrid retrieval → grounded RCA.

## Design principle

Keep the frontend independent from the research implementation.

For example, the frontend only needs:

GET /api/v1/rca/investigate/{incident_id}

It should not care whether the backend later uses:
- rules
- ML
- graph traversal
- vector search
- an LLM
- a combined pipeline

This allows the research implementation to evolve without rebuilding the UI.
