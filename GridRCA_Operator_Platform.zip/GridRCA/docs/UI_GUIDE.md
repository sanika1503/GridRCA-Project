# Operator UI

The frontend contains these operational views:

1. Operations
   - overall grid status
   - active incidents
   - latest telemetry
   - topology snapshot

2. Live Telemetry
   - latest signal measurements
   - refresh control
   - anomaly/warning status

3. Incident Command
   - incident list
   - selected incident details
   - RCA launch

4. Topology & Data Lineage
   - network relationship visualization
   - grid entity list

5. RCA Investigation
   - incident ID
   - investigation trigger
   - probable cause
   - confidence
   - evidence
   - recommendation

6. Evidence Repository
   - planned sources and provenance pipeline

7. System
   - frontend/backend/database/graph/RAG status

The interface is deliberately formal and operator-oriented rather than chatbot-oriented.
