# Dataset Integration Plan

The current dataset is PSML.

Do not build assumptions into the database before inspecting the exact files.

## Planned flow

PSML ZIP
  ↓
data/raw/psml/archive
  ↓ extract
data/raw/psml/extracted
  ↓ inspect
schema map
  ↓
PSML ingestion script
  ↓
data/processed/psml
  ↓
PostgreSQL telemetry/assets/events

Topology-related data will later also populate Neo4j.

The database design will be adapted to the actual PSML fields after inspection.
