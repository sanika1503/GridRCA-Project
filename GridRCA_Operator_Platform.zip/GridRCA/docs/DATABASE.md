# PostgreSQL integration

## Create database

In pgAdmin or psql:

CREATE DATABASE gridrca;

## Configure

Copy .env.example to .env.

Set:

DATABASE_URL=postgresql+psycopg://postgres:YOUR_PASSWORD@localhost:5432/gridrca

## Initialize

From project root:

python backend/scripts/init_db.py

## Current tables

grid_assets
telemetry
incidents
rca_results

## Later tables

anomaly_events
maintenance_records
dataset_metadata
rca_ground_truth
rca_evaluation
