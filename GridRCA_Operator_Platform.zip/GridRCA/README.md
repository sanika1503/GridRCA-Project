# GridRCA — Grid Operator Intelligence Platform

GridRCA is a professional power-grid monitoring and root-cause investigation platform.

## Architecture

Browser
  ↓
React + Vite frontend
  ↓ REST/JSON
FastAPI backend
  ├── PostgreSQL → structured grid/telemetry/incidents data
  ├── Neo4j      → topology/data-lineage relationships (prepared, optional now)
  └── RAG layer  → Chroma/documents (prepared for later)

The current starter is deliberately usable before the complete research pipeline is implemented:
- React/Vite operator dashboard
- FastAPI API
- PostgreSQL connection and database initialization
- Demo telemetry/incidents/RCA data when database tables are empty
- PSML dataset folders ready for your extracted data
- Neo4j connection health endpoint prepared
- RAG/knowledge folders prepared
- Synthetic-data folders prepared
- Clear separation between UI, API, services, database and future research modules

## Why FastAPI + React instead of Streamlit?

### FastAPI
FastAPI is the backend/API layer. It is a better fit because GridRCA is an operational system, not a notebook or chatbot:
- clean REST APIs
- strong request/response validation
- easy integration with PostgreSQL/Neo4j/vector databases
- asynchronous capabilities for future streaming
- easy separation of anomaly detection, graph, retrieval and RCA services
- frontend can be replaced without rewriting the backend

### React + Vite
React provides a real operator-facing application:
- persistent navigation
- reusable components
- multiple screens
- live dashboards
- topology/incident/RCA views
- future WebSocket/live-stream support
- formal control-room style UI

### Why not make Streamlit the main UI?
Streamlit is excellent for prototypes, experiments and data science demos. For a continuously operated grid-control-style interface with multiple linked pages, persistent state, rich interactions and a separate API/data layer, React + FastAPI is the stronger architecture.

## Current scope

This version is the working foundation. It intentionally does NOT pretend that the full research system is finished.

Working now:
1. Frontend ↔ FastAPI REST connection
2. FastAPI ↔ PostgreSQL connection
3. Database schema initialization
4. Operator dashboard pages
5. Demo/live telemetry endpoint
6. Incident endpoint
7. RCA endpoint
8. Topology endpoint with a demo graph
9. System health/status endpoint
10. PSML/raw/processed/synthetic/knowledge directory structure

Prepared for later:
- PSML ingestion
- real anomaly detection
- Neo4j topology population
- hybrid RAG
- embeddings/vector database
- historical incident corpus
- maintenance data
- synthetic scenarios and ground truth
- automated RCA scoring
- WebSocket/streaming telemetry

## Project layout

GridRCA/
├── backend/
│   ├── app/
│   │   ├── api/                 # REST endpoints
│   │   ├── core/                # settings/configuration
│   │   ├── db/                  # PostgreSQL + optional Neo4j
│   │   ├── models/              # SQLAlchemy tables
│   │   ├── schemas/             # API validation models
│   │   └── services/            # business logic
│   └── scripts/                 # initialization/import helpers
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   └── services/
│   └── package.json
├── data/
│   ├── raw/psml/                # put extracted PSML files here
│   ├── processed/psml/
│   ├── synthetic/
│   ├── knowledge/documents/
│   ├── knowledge/chroma/
│   ├── topology/
│   ├── incidents/
│   └── maintenance/
├── database/
│   └── README.md
├── docs/
│   ├── ARCHITECTURE.md
│   ├── DATABASE.md
│   ├── DATASET_GUIDE.md
│   └── UI_GUIDE.md
├── .env.example
├── docker-compose.yml
└── requirements.txt

## Quick start — Windows + VS Code

### 1. Backend

Open a terminal at the project root:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Copy `.env.example` to `.env` and set your PostgreSQL credentials.

Then:

```powershell
python backend/scripts/init_db.py
uvicorn backend.app.main:app --reload
```

API:
- http://127.0.0.1:8000
- http://127.0.0.1:8000/docs
- http://127.0.0.1:8000/api/v1/health

### 2. Frontend

Install Node.js LTS if it is not already installed.

```powershell
cd frontend
npm install
npm run dev
```

Open the URL shown by Vite, normally:
http://localhost:5173

The frontend is already configured to call:
http://127.0.0.1:8000/api/v1

## PostgreSQL

Create a database, for example:

```sql
CREATE DATABASE gridrca;
```

Then put the actual credentials in `.env`:

```env
DATABASE_URL=postgresql+psycopg://postgres:YOUR_PASSWORD@localhost:5432/gridrca
```

The initialization script creates the starter tables.

## PSML dataset

Do NOT put the PSML ZIP directly into application Python code.

Use:

data/raw/psml/

Extract the dataset there. Keep the original ZIP in:

data/raw/psml/archive/

Then we will inspect its exact files and build a dedicated PSML ingestion script.

The project is intentionally ready for you to paste the PSML data later.

## Important

The demo data shown by the UI is a fallback/seed layer. Once real PSML and database records are loaded, the same frontend/API structure can consume real records.

Do not describe the demo RCA confidence values as research results. They are UI integration data only.
